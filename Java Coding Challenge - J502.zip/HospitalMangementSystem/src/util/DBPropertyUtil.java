package util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getPropertyString(String fileName) {
        Properties prop = new Properties();
        String connectionString = "";
        try (FileInputStream fis = new FileInputStream(fileName)) {
            prop.load(fis);
            String host = prop.getProperty("hostname");
            String port = prop.getProperty("port");
            String db = prop.getProperty("dbname");
            String user = prop.getProperty("username");
            String pass = prop.getProperty("password");

            connectionString = "jdbc:mysql://" + host + ":" + port + "/" + db + "?user=" + user + "&password=" + pass;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return connectionString;
    }
}
