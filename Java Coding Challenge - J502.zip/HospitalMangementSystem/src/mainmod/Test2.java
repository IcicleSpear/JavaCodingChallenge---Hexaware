package mainmod;

import dao.HospitalServiceImpl;
import entity.Appointment;
import myexceptions.AppointmentNotFoundException;
import myexceptions.DoctorNumberNotFoundException;
import myexceptions.PatientNumberNotFoundException;

import java.util.List;
import java.util.Scanner;

public class Test2 {

    public static void main(String[] args) {
        HospitalServiceImpl service = new HospitalServiceImpl();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Hospital Management Menu ===");
            System.out.println("1. Get Appointment by ID");
            System.out.println("2. Get Appointments for Patient");
            System.out.println("3. Get Appointments for Doctor");
            System.out.println("4. Schedule a New Appointment");
            System.out.println("5. Update an Appointment");
            System.out.println("6. Cancel Appointment");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter Appointment ID: ");
                        int apptId = sc.nextInt();
                        Appointment appt = service.getAppointmentById(apptId);
                        if (appt != null) System.out.println(appt);
                        break;

                    case 2:
                        System.out.print("Enter Patient ID: ");
                        int patientId = sc.nextInt();
                        List<Appointment> patientAppointments = service.getAppointmentsForPatient(patientId);
                        for (Appointment a : patientAppointments) {
                            System.out.println(a);
                        }
                        break;

                    case 3:
                        System.out.print("Enter Doctor ID: ");
                        int doctorId = sc.nextInt();
                        List<Appointment> doctorAppointments = service.getAppointmentsForDoctor(doctorId);
                        for (Appointment a : doctorAppointments) {
                            System.out.println(a);
                        }
                        break;

                    case 4:
                        System.out.print("Enter Patient ID: ");
                        int newPatientId = sc.nextInt();
                        System.out.print("Enter Doctor ID: ");
                        int newDoctorId = sc.nextInt();
                        sc.nextLine(); // consume newline
                        System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
                        String date = sc.nextLine();
                        System.out.print("Enter Description: ");
                        String desc = sc.nextLine();

                        Appointment newAppt = new Appointment(0, newPatientId, newDoctorId, date, desc);
                        if (service.scheduleAppointment(newAppt)) {
                            System.out.println("Appointment scheduled successfully!");
                        } else {
                            System.out.println("Failed to schedule appointment.");
                        }
                        break;

                    case 5:
                        System.out.print("Enter Appointment ID to Update: ");
                        int updateId = sc.nextInt();
                        System.out.print("Enter New Patient ID: ");
                        int updPatientId = sc.nextInt();
                        System.out.print("Enter New Doctor ID: ");
                        int updDoctorId = sc.nextInt();
                        sc.nextLine(); 
                        System.out.print("Enter New Date (YYYY-MM-DD): ");
                        String updDate = sc.nextLine();
                        System.out.print("Enter New Description: ");
                        String updDesc = sc.nextLine();

                        Appointment updatedAppt = new Appointment(updateId, updPatientId, updDoctorId, updDate, updDesc);
                        if (service.updateAppointment(updatedAppt)) {
                            System.out.println("Appointment updated successfully!");
                        } else {
                            System.out.println("Failed to update appointment.");
                        }
                        break;

                    case 6:
                        System.out.print("Enter Appointment ID to Cancel: ");
                        int cancelId = sc.nextInt();
                        if (service.cancelAppointment(cancelId)) {
                            System.out.println("Appointment cancelled successfully!");
                        } else {
                            System.out.println("Failed to cancel appointment.");
                        }
                        break;

                    case 0:
                        System.out.println("Exiting program. Thank you!");
                        sc.close();
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice. Try again.");
                }

            } catch (PatientNumberNotFoundException e) {
                System.out.println("Patient error: " + e.getMessage());
            } catch (DoctorNumberNotFoundException e) {
                System.out.println("Doctor error: " + e.getMessage());
            } catch (AppointmentNotFoundException e) {
                System.out.println("Appointment error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Something went wrong: " + e.getMessage());
            }
        }
    }
}
