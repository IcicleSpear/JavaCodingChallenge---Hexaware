package mainmod;

import java.util.List;
import java.util.Scanner;

import dao.HospitalServiceImpl;
import dao.IHospitalService;
import entity.Appointment;
import myexceptions.AppointmentNotFoundException;
import myexceptions.DoctorNumberNotFoundException;
import myexceptions.PatientNumberNotFoundException;

public class MainModule {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        IHospitalService service = new HospitalServiceImpl();

        while (true) {
            System.out.println("\n=== Hospital Management Menu ===");
            System.out.println("1. Get Appointment by ID");
            System.out.println("2. Get Appointments for Patient");
            System.out.println("3. Get Appointments for Doctor");
            System.out.println("4. Schedule a New Appointment");
            System.out.println("5. Update an Appointment");
            System.out.println("6. Cancel Appointment");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Appointment ID: ");
                    int appId = sc.nextInt();
                    try {
                        Appointment appointment = service.getAppointmentById(appId);
                        System.out.println(appointment);
                    } catch (AppointmentNotFoundException e) {
                        System.out.println("Appointment error: " + e.getMessage());
                    }
                    break;

                case 2:
                    System.out.print("Enter Patient ID: ");
                    int patientId = sc.nextInt();
                    try {
                        List<Appointment> patientAppointments = service.getAppointmentsForPatient(patientId);
                        for (Appointment app : patientAppointments) {
                            System.out.println(app);
                        }
                    } catch (PatientNumberNotFoundException e) {
                        System.out.println("Patient error: " + e.getMessage());
                    }
                    break;

                case 3:
                    System.out.print("Enter Doctor ID: ");
                    int doctorId = sc.nextInt();
                    try {
                        List<Appointment> doctorAppointments = service.getAppointmentsForDoctor(doctorId);
                        for (Appointment app : doctorAppointments) {
                            System.out.println(app);
                        }
                    } catch (DoctorNumberNotFoundException e) {
                        System.out.println("Doctor error: " + e.getMessage());
                    }
                    break;

                case 4:
                    System.out.print("Enter Patient ID: ");
                    int newPatientId = sc.nextInt();
                    System.out.print("Enter Doctor ID: ");
                    int newDoctorId = sc.nextInt();
                    System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
                    String date = sc.next();
                    System.out.print("Enter Description: ");
                    sc.nextLine(); // clear buffer
                    String desc = sc.nextLine();

                    Appointment newAppointment = new Appointment(0, newPatientId, newDoctorId, date, desc);
                    try {
                        boolean success = service.scheduleAppointment(newAppointment);
                        System.out.println(success ? "Appointment scheduled successfully." : "Failed to schedule appointment.");
                    } catch (PatientNumberNotFoundException e) {
                        System.out.println("Patient error: " + e.getMessage());
                    } catch (DoctorNumberNotFoundException e) {
                        System.out.println("Doctor error: " + e.getMessage());
                    }
                    break;

                case 5:
                    System.out.print("Enter Appointment ID to Update: ");
                    int updAppId = sc.nextInt();
                    System.out.print("Enter New Patient ID: ");
                    int updPatientId = sc.nextInt();
                    System.out.print("Enter New Doctor ID: ");
                    int updDoctorId = sc.nextInt();
                    System.out.print("Enter New Date (YYYY-MM-DD): ");
                    String updDate = sc.next();
                    System.out.print("Enter New Description: ");
                    sc.nextLine(); // clear buffer
                    String updDesc = sc.nextLine();

                    Appointment updatedApp = new Appointment(updAppId, updPatientId, updDoctorId, updDate, updDesc);
                    try {
                        boolean updated = service.updateAppointment(updatedApp);
                        System.out.println(updated ? "Appointment updated successfully." : "Failed to update appointment.");
                    } catch (PatientNumberNotFoundException e) {
                        System.out.println("Patient error: " + e.getMessage());
                    } catch (DoctorNumberNotFoundException e) {
                        System.out.println("Doctor error: " + e.getMessage());
                    } catch (AppointmentNotFoundException e) {
                        System.out.println("Appointment error: " + e.getMessage());
                    }
                    break;

                case 6:
                    System.out.print("Enter Appointment ID to Cancel: ");
                    int cancelId = sc.nextInt();
                    try {
                        boolean cancelled = service.cancelAppointment(cancelId);
                        System.out.println(cancelled ? "Appointment cancelled successfully." : "Failed to cancel appointment.");
                    } catch (AppointmentNotFoundException e) {
                        System.out.println("Appointment error: " + e.getMessage());
                    }
                    break;

                case 0:
                    System.out.println("Exiting the application.");
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}
