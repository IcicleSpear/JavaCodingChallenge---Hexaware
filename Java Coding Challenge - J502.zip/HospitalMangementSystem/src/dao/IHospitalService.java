package dao;

import java.util.List;
import myexceptions.AppointmentNotFoundException;
import myexceptions.DoctorNumberNotFoundException;
import myexceptions.PatientNumberNotFoundException;

import entity.Appointment;

public interface IHospitalService {
	
	 Appointment getAppointmentById(int appointmentId) throws AppointmentNotFoundException;
	 List<Appointment> getAppointmentsForPatient(int patientId) throws PatientNumberNotFoundException;
	 List<Appointment> getAppointmentsForDoctor(int doctorId) throws DoctorNumberNotFoundException;
	 boolean scheduleAppointment(Appointment appointment) throws PatientNumberNotFoundException, DoctorNumberNotFoundException;
	 boolean updateAppointment(Appointment appointment) throws AppointmentNotFoundException, PatientNumberNotFoundException, DoctorNumberNotFoundException;
	 boolean cancelAppointment(int appointmentId) throws AppointmentNotFoundException;
}
