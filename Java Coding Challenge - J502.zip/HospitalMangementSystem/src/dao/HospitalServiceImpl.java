package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import entity.Appointment;
import util.DBConnUtil;

import myexceptions.AppointmentNotFoundException;
import myexceptions.DoctorNumberNotFoundException;
import myexceptions.PatientNumberNotFoundException;

public class HospitalServiceImpl implements IHospitalService {

    private Connection conn;

    public HospitalServiceImpl() {
        try {
            this.conn = DBConnUtil.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isPatientExists(int patientId) {
        try {
            String query = "SELECT 1 FROM patients WHERE patientid = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean isDoctorExists(int doctorId) {
        try {
            String query = "SELECT 1 FROM doctors WHERE doctorid = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, doctorId);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public Appointment getAppointmentById(int appointmentId) throws AppointmentNotFoundException {
        Appointment appointment = null;
        try {
            String query = "SELECT * FROM appointments WHERE appointmentid = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, appointmentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                appointment = new Appointment(
                        rs.getInt("appointmentid"),
                        rs.getInt("patientid"),
                        rs.getInt("doctorid"),
                        rs.getString("appointmentdate"),
                        rs.getString("description"));
            } else {
                throw new AppointmentNotFoundException("Appointment ID not found: " + appointmentId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointment;
    }

    @Override
    public List<Appointment> getAppointmentsForPatient(int patientId) throws PatientNumberNotFoundException {
        if (!isPatientExists(patientId)) {
            throw new PatientNumberNotFoundException("Patient ID not found: " + patientId);
        }

        List<Appointment> list = new ArrayList<>();
        try {
            String query = "SELECT * FROM appointments WHERE patientid = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Appointment appointment = new Appointment(
                        rs.getInt("appointmentid"),
                        rs.getInt("patientid"),
                        rs.getInt("doctorid"),
                        rs.getString("appointmentdate"),
                        rs.getString("description"));
                list.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Appointment> getAppointmentsForDoctor(int doctorId) throws DoctorNumberNotFoundException {
        if (!isDoctorExists(doctorId)) {
            throw new DoctorNumberNotFoundException("Doctor ID not found: " + doctorId);
        }

        List<Appointment> list = new ArrayList<>();
        try {
            String query = "SELECT * FROM appointments WHERE doctorid = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, doctorId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Appointment appointment = new Appointment(
                        rs.getInt("appointmentid"),
                        rs.getInt("patientid"),
                        rs.getInt("doctorid"),
                        rs.getString("appointmentdate"),
                        rs.getString("description"));
                list.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean scheduleAppointment(Appointment appointment)
            throws PatientNumberNotFoundException, DoctorNumberNotFoundException {

        if (!isPatientExists(appointment.getPatientId())) {
            throw new PatientNumberNotFoundException("Patient ID not found: " + appointment.getPatientId());
        }

        if (!isDoctorExists(appointment.getDoctorId())) {
            throw new DoctorNumberNotFoundException("Doctor ID not found: " + appointment.getDoctorId());
        }

        try {
            String query = "INSERT INTO appointments(patientid, doctorid, appointmentdate, description) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, appointment.getPatientId());
            ps.setInt(2, appointment.getDoctorId());
            ps.setString(3, appointment.getAppointmentDate());
            ps.setString(4, appointment.getDescription());
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateAppointment(Appointment appointment)
            throws PatientNumberNotFoundException, DoctorNumberNotFoundException {

        if (!isPatientExists(appointment.getPatientId())) {
            throw new PatientNumberNotFoundException("Patient ID not found: " + appointment.getPatientId());
        }

        if (!isDoctorExists(appointment.getDoctorId())) {
            throw new DoctorNumberNotFoundException("Doctor ID not found: " + appointment.getDoctorId());
        }

        try {
            String query = "UPDATE appointments SET patientid = ?, doctorid = ?, appointmentdate = ?, description = ? WHERE appointmentid = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, appointment.getPatientId());
            ps.setInt(2, appointment.getDoctorId());
            ps.setString(3, appointment.getAppointmentDate());
            ps.setString(4, appointment.getDescription());
            ps.setInt(5, appointment.getAppointmentId());
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean cancelAppointment(int appointmentId) throws AppointmentNotFoundException {
        // First, verify appointment exists
        try {
            String checkQuery = "SELECT 1 FROM appointments WHERE appointmentid = ?";
            PreparedStatement checkPs = conn.prepareStatement(checkQuery);
            checkPs.setInt(1, appointmentId);
            ResultSet rs = checkPs.executeQuery();
            if (!rs.next()) {
                throw new AppointmentNotFoundException("Appointment ID not found: " + appointmentId);
            }

            String query = "DELETE FROM appointments WHERE appointmentid = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, appointmentId);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
